# Weather-application
This weather app displays real time weather conditions using API’S along with weather description and the user's city and country
